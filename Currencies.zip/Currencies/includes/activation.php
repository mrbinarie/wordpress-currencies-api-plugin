<?php

if (!defined('ABSPATH') ) {
    exit; // Exit if accessed directly.
}

if (is_multisite())
{
    $subsidiary = get_bloginfo('name');
    if (!get_site_option($subsidiary))
    {
        $api_key = wp_generate_password(32, false);
        add_site_option($subsidiary, $api_key);

        wp_redirect(admin_url('admin.php?page=subsidiary_currencies&status=success'));
    }
}