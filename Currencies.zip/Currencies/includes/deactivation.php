<?php

if (!defined('ABSPATH') ) {
    exit; // Exit if accessed directly.
}

if (is_multisite())
{
    $subsidiary = get_bloginfo('name');
    if (get_site_option($subsidiary))
    {
        delete_site_option($subsidiary);
    }
}