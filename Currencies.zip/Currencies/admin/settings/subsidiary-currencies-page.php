<?php

if (!defined('ABSPATH') ) {
    exit; // Exit if accessed directly.
}

function subsidiary_currencies_page() {
    global $wpdb;
    $currencies_table = $wpdb->base_prefix . 'currencies';

    // Get the current subsidiary name
    $subsidiary = get_bloginfo('name');


    $site_id = get_id_from_blogname($subsidiary);

    // Fetch currencies data specific to the current subsidiary
    $currencies = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $currencies_table WHERE site_id = %d",
        $site_id
    ));

    echo '<div class="wrap">';
    
    // Display API request details
    echo '<h2>API Request Details</h2>';
    echo '<p><strong>URL:</strong> ' . network_site_url("/wp-json/currencies-api/v1/$subsidiary/currencies") . '</p>';
    echo '<p><strong>Headers:</strong> X-API-KEY: ' . get_site_option($subsidiary) . '</p>';

    echo '<h1>Currencies Data for ' . esc_html($subsidiary) . '</h1>';

    // Display currencies data
    echo '<h2>Currencies</h2>';
    echo '<table class="widefat fixed" cellspacing="0">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>Currency</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    if ($currencies) {
        foreach ($currencies as $currency) {
            echo '<tr>';
            echo '<td>' . esc_html($currency->id) . '</td>';
            echo '<td>' . esc_html($currency->currency) . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="2">No currencies found</td></tr>';
    }
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}


/*
if (!get_site_option($subsidiary)) {
    <div class="wrap">
        <div class="notice notice-primary">
            <p>Would you like to establish a database for currencies and generate an API key?</p>
            <form method="post" action="">
                <p><input type="submit" name="submit_create_currencies_button" class="button button-primary" value="Confirm"></p>
            </form>
        </div>
    </div>
}

// Hook to handle the form submission.
add_action( 'admin_init', 'submit_create_currencies_handle' );

function submit_create_currencies_handle()
{
    if ( isset( $_POST['submit_create_currencies_button'] ))
    {
        if (is_multisite())
        {
            $subsidiary = get_bloginfo('name');
            if (!get_site_option($subsidiary))
            {
                $api_key = wp_generate_password(32, false);
                add_site_option($subsidiary, $api_key);

                wp_redirect(admin_url('admin.php?page=subsidiary_currencies&status=success'));
            }
        }
    }
}
*/