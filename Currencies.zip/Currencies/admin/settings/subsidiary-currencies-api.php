<?php

if (!defined('ABSPATH') ) {
    exit; // Exit if accessed directly.
}

// Function to display API Documentation page
function subsidiary_currencies_api_page() {
    
    $subsidiary = get_bloginfo('name');
    ?>

    <h1>API Documentation</h1>
    <p><strong>URL:</strong> <?= network_site_url("/wp-json/currencies-api/v1/$subsidiary/currencies") ?></p>
    <p><strong>Headers:</strong> X-API-KEY: <?= get_site_option($subsidiary) ?></p>
    
    <?php
}